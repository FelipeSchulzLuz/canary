rm -f myaac-tibia12-login.zip
zip -r myaac-tibia12-login.zip plugins/ login.php -x */\.*
